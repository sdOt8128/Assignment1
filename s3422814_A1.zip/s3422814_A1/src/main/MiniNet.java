package main;

public class MiniNet {
	

	
	public static void main(String[] args) 
	{	
		Driver menu = new Driver();
		menu.runMenu();
		// Press 11 first to read in profile data.
		
	}	
}